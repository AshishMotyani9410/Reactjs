export const questions = [
    {
        "id": 1,
        "question": "What is the capital of Pakistan?",
        "options": [
            {
                "a": "Karachi",
                "b": "Islamabad",
                "c": "Lahore",
                "d": "None"
            }
        ],
        "answer": "Islamabad",
        "score": 0,
        "status": ""
    },
    {
        "id": 2,
        "question": "Where is the Cricket National Stadium?",
        "options": [
            {
                "a": "Islamabad",
                "b": "Gawader",
                "c": "Lahore",
                "d": "Karachi"
            }
        ],
        "answer": "Karachi",
        "score": 0,
        "status": ""
    },
    {
        "id": 3,
        "question": "Which of the following building is the largest in Pakistan",
        "options": [
            {
                "a": "Bahria Icon Tower",
                "b": "Chapal Skymark",
                "c": "Dolmen Tower",
                "d": "MCB Tower"
            }
        ],
        "answer": "Bahria Icon Tower",
        "score": 0,
        "status": ""
    },
    {
        "id": 4,
        "question": "Karakoram Highway is the highest road ever built?",
        "options": [
            {
                "a": "True",
                "b": "False"
            }
        ],
        "answer": "True",
        "score": 0,
        "status": ""
    },
    {
        "id": 5,
        "question": "Pakistan’s Sialkot produces over half the world’s footballs?",
        "options": [
            {
                "a": "True",
                "b": "False"
            }
        ],
        "answer": "True",
        "score": 0,
        "status": ""
    }
];
