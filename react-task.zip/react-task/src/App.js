import './App.css';
import QuizContainer from './components/QuizContainer'

function App() {
  return (
    <div>
      <QuizContainer></QuizContainer>
    </div>
  );
}

export default App;
